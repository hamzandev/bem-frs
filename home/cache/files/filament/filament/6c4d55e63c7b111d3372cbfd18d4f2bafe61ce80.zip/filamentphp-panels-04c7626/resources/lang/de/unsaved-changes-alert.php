<?php

return [

    'body' => 'Sie haben ungespeicherte Änderungen. Sind Sie sicher, dass Sie diese Seite verlassen wollen?',

];
