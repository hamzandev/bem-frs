<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'ログアウト',
        ],

    ],

    'welcome' => 'ようこそ',

];
