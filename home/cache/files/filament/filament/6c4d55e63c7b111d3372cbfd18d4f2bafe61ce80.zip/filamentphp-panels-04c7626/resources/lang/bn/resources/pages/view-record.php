<?php

return [

    'title' => ':label দেখুন',

    'breadcrumb' => 'দেখুন',

    'content' => [

        'tab' => [
            'label' => 'দেখুন',
        ],

    ],

];
