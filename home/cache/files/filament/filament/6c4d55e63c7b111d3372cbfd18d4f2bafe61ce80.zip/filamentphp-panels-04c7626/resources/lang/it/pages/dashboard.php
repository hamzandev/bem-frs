<?php

return [

    'title' => 'Dashboard',

    'actions' => [

        'filter' => [

            'label' => 'Filtro',

            'modal' => [

                'heading' => 'Filtro',

                'actions' => [

                    'apply' => [

                        'label' => 'Applica',

                    ],

                ],

            ],

        ],

    ],

];
