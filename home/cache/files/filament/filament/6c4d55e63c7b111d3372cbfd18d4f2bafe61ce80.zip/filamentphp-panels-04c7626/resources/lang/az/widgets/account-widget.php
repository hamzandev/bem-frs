<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Çıxış',
        ],

    ],

    'welcome' => 'Xoş gəldin',

];
