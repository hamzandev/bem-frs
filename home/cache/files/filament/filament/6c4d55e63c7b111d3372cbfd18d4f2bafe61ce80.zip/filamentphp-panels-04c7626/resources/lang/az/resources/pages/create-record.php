<?php

return [

    'title' => ':label yarat',

    'breadcrumb' => 'Yarat',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'İmtina',
            ],

            'create' => [
                'label' => 'Yarat',
            ],

            'create_another' => [
                'label' => 'Yarat & yenisini yarat',
            ],

        ],

    ],

    'notifications' => [

        'created' => [
            'title' => 'Yaradıldı',
        ],

    ],

];
