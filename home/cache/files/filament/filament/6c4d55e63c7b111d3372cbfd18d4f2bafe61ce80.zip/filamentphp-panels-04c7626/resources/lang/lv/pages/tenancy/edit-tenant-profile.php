<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Saglabāt izmaiņas',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Izmaiņas saglabātas',
        ],

    ],

];
