<?php

return [

    'title' => ':label 詳細',

    'breadcrumb' => '詳細',

    'content' => [

        'tab' => [
            'label' => '詳細',
        ],

    ],

];
