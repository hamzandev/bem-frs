<?php

namespace Filament\Infolists\Components;

/**
 * @deprecated Use `Section` with an empty heading instead.
 */
class Card extends Section
{
}
