<?php

return [

    'single' => [

        'label' => 'سڕینەوە',

        'modal' => [

            'heading' => 'سڕینەوەی :label',

            'actions' => [

                'delete' => [
                    'label' => 'سڕینەوە',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'سڕدرایەوە',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'سڕینەوەی دیاریکراوەکان',

        'modal' => [

            'heading' => 'سڕینەوەی دیاریکراوەکانی :label',

            'actions' => [

                'delete' => [
                    'label' => 'سڕینەوە',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'سڕدرایەوە',
            ],

        ],

    ],

];
