<?php

return [

    'title' => 'ड्यासबोर्ड',

    'actions' => [

        'filter' => [

            'label' => 'फिल्टर',

            'modal' => [

                'heading' => 'फिल्टर',

                'actions' => [

                    'apply' => [

                        'label' => 'लागू गर्नुहोस्',

                    ],

                ],

            ],

        ],

    ],

];
