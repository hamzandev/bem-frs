<?php

return [

    'single' => [

        'label' => 'Ubah',

        'modal' => [

            'heading' => 'Ubah :label',

            'actions' => [

                'save' => [
                    'label' => 'Simpan',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Data berhasil disimpan',
            ],

        ],

    ],

];
