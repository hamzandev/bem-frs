<?php

return [

    'single' => [

        'label' => 'Atkurti',

        'modal' => [

            'heading' => 'Atkurti :label',

            'actions' => [

                'restore' => [
                    'label' => 'Atkurti',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Atkurta',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Atkurti pasirinktus',

        'modal' => [

            'heading' => 'Atkurti pasirinktus :label',

            'actions' => [

                'restore' => [
                    'label' => 'Atkurti',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Atkurta',
            ],

        ],

    ],

];
