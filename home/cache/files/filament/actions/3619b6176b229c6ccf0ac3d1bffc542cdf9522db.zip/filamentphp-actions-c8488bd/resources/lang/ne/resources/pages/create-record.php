<?php

return [

    'title' => 'सिर्जना :label',

    'breadcrumb' => 'सिर्जना',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'रद्द गर्नुहोस्',
            ],

            'create' => [
                'label' => 'सिर्जना गर्नुहोस्',
            ],

            'create_another' => [
                'label' => 'अर्को सिर्जना गर्नुहोस्',
            ],

        ],

    ],

    'notifications' => [

        'created' => [
            'title' => 'सिर्जना भयो',
        ],

    ],

];
