<?php

return [

    'single' => [

        'label' => 'Lampirkan',

        'modal' => [

            'heading' => 'Lampirkan :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Data',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Lampirkan',
                ],

                'attach_another' => [
                    'label' => 'Lampirkan & lampirkan lainnya',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Data berhasil dilampirkan',
            ],

        ],

    ],

];
