<?php

return [

    'single' => [

        'label' => 'Դիտել',

        'modal' => [

            'heading' => 'Դիտել :label',

            'actions' => [

                'close' => [
                    'label' => 'Փակել',
                ],

            ],

        ],

    ],

];
