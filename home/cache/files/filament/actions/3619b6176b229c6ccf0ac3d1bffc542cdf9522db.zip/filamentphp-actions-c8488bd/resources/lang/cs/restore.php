<?php

return [

    'single' => [

        'label' => 'Obnovit',

        'modal' => [

            'heading' => 'Obnovit :label',

            'actions' => [

                'restore' => [
                    'label' => 'Obnovit',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Obnoveno',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Obnovit vybrané',

        'modal' => [

            'heading' => 'Obnovit vybrané :label',

            'actions' => [

                'restore' => [
                    'label' => 'Obnovit',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Obnoveno',
            ],

        ],

    ],

];
