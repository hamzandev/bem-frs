<?php

return [

    'single' => [

        'label' => 'Hapus selamanya',

        'modal' => [

            'heading' => 'Hapus selamanya :label',

            'actions' => [

                'delete' => [
                    'label' => 'Hapus',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Data berhasil dihapus',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Hapus selamanya data yang dipilih',

        'modal' => [

            'heading' => 'Hapus selamanya :label yang dipilih',

            'actions' => [

                'delete' => [
                    'label' => 'Hapus',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Data berhasil dihapus',
            ],

        ],

    ],

];
