<?php

return [

    'single' => [

        'label' => 'دەستکارکردن',

        'modal' => [

            'heading' => 'دەستکارکردنی :label',

            'actions' => [

                'save' => [
                    'label' => 'نوێکردنەوە',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'نوێکرایەوە',
            ],

        ],

    ],

];
