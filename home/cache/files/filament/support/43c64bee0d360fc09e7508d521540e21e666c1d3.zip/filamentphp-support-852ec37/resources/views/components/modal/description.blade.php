<p
    {{ $attributes->class(['fi-modal-description text-sm text-gray-500 dark:text-gray-400']) }}
>
    {{ $slot }}
</p>
