<?php

return [

    'messages' => [
        'copied' => 'コピーしました',
    ],

];
