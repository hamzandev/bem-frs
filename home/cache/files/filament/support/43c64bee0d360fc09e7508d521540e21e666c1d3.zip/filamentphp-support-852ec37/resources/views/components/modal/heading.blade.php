<h2
    {{ $attributes->class(['fi-modal-heading text-base font-semibold leading-6 text-gray-950 dark:text-white']) }}
>
    {{ $slot }}
</h2>
