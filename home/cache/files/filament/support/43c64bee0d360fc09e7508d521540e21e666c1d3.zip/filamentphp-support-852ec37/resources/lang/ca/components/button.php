<?php

return [

    'messages' => [
        'uploading_file' => 'Pujant arxiu...',
    ],

];
