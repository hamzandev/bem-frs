<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Uždaryti',
        ],

    ],

];
