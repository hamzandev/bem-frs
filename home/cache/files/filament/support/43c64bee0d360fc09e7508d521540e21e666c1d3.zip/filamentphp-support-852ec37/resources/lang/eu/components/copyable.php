<?php

return [

    'messages' => [
        'copied' => 'Kopiatuta',
    ],

];
