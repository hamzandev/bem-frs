<?php

return [

    'messages' => [
        'uploading_file' => 'Memuat naik fail...',
    ],

];
