<?php

return [

    'messages' => [
        'copied' => 'Kopieret',
    ],

];
