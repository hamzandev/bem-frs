<?php

namespace Filament\Widgets\View;

class WidgetsRenderHook
{
    const TABLE_WIDGET_END = 'widgets::table-widget.end';

    const TABLE_WIDGET_START = 'widgets::table-widget.start';
}
