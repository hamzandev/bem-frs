<?php

return [

    'modal' => [

        'heading' => 'Bildirishnomalar',

        'actions' => [

            'clear' => [
                'label' => 'O\'chirish',
            ],

            'mark_all_as_read' => [
                'label' => 'O\'qilgan deb belgilash',
            ],

        ],

        'empty' => [
            'heading' => 'Bildirishnomalar mavjud emas',
            'description' => 'Iltimos keyinroq tekshiring',
        ],

    ],

];
