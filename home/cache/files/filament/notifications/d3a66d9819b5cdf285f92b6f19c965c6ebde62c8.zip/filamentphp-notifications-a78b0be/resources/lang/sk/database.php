<?php

return [

    'modal' => [

        'heading' => 'Notifikácie',

        'actions' => [

            'clear' => [
                'label' => 'Odstrániť',
            ],

            'mark_all_as_read' => [
                'label' => 'Označiť všetko ako prečítané',
            ],

        ],

        'empty' => [
            'heading' => 'Žiadne notifikácie',
            'description' => 'Skúste to prosím neskôr.',
        ],

    ],

];
