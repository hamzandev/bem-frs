<?php

return [

    'distinct' => [
        'must_be_selected' => 'Musí byť vybrané aspoň jedno pole :attribute.',
        'only_one_must_be_selected' => 'Musí byť vybrané iba jedno pole :attribute.',
    ],

];
