<?php

return [

    'distinct' => [
        'must_be_selected' => 'Se debe seleccionar al menos un campo :attribute.',
        'only_one_must_be_selected' => 'Se debe seleccionar solamente un campo :attribute.',
    ],

];
