<?php

return [

    'distinct' => [
        'must_be_selected' => 'S\'ha de seleccionar almenys un camp :attribute.',
        'only_one_must_be_selected' => 'S\'ha de seleccionar només un camp :attribute.',
    ],

];
