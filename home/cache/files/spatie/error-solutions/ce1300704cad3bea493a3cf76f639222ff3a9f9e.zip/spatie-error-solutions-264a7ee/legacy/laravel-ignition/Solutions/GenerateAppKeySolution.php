<?php

namespace Spatie\LaravelIgnition\Solutions;

use Spatie\ErrorSolutions\Solutions\Laravel\GenerateAppKeySolution as BaseGenerateAppKeySolutionAlias;
use Spatie\Ignition\Contracts\Solution;

class GenerateAppKeySolution extends BaseGenerateAppKeySolutionAlias implements Solution
{

}
