<?php

namespace Spatie\Ignition\Solutions\OpenAi;

class OpenAiPromptViewModel extends \Spatie\ErrorSolutions\Solutions\OpenAi\OpenAiPromptViewModel
{
}
