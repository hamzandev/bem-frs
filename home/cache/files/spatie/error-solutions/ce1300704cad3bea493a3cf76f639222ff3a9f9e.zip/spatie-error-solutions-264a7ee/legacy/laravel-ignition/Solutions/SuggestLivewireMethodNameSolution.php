<?php

namespace Spatie\LaravelIgnition\Solutions;

use Spatie\ErrorSolutions\Solutions\Laravel\SuggestLivewireMethodNameSolution as BaseSuggestLivewireMethodNameSolutionAlias;
use Spatie\Ignition\Contracts\Solution;

class SuggestLivewireMethodNameSolution extends BaseSuggestLivewireMethodNameSolutionAlias implements Solution
{
}
