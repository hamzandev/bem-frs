<?php

namespace Spatie\LaravelIgnition\Solutions;

use Spatie\ErrorSolutions\Solutions\Laravel\SuggestLivewirePropertyNameSolution as BaseSuggestLivewirePropertyNameSolutionAlias;
use Spatie\Ignition\Contracts\Solution;

class SuggestLivewirePropertyNameSolution extends BaseSuggestLivewirePropertyNameSolutionAlias implements Solution
{

}
