<?php

namespace Spatie\Ignition\Solutions\OpenAi;

class OpenAiSolutionResponse extends \Spatie\ErrorSolutions\Solutions\OpenAi\OpenAiSolutionResponse
{

}
