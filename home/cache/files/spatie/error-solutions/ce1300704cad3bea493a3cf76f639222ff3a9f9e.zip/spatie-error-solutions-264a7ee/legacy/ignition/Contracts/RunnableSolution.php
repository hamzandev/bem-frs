<?php

namespace Spatie\Ignition\Contracts;

interface RunnableSolution extends \Spatie\ErrorSolutions\Contracts\RunnableSolution
{
}
